library(testthat)
library(rliesel)

test_check("rliesel")
